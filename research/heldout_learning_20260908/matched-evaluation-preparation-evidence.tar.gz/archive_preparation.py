"""Freeze preparation and partial validation evidence without touching a run."""

import hashlib
import io
import json
import tarfile
from pathlib import Path

ROOT = Path('/home/chen/runs/heldout-learning-20260908')
PROJECT = Path('/home/chen/projects/self-play-in-the-causal-world-rewardv10-a92ab8e-20260831')


def sha(data):
    return hashlib.sha256(data).hexdigest()


files = {}
for name in [
    'control_matched_evaluation.py', 'read_validation.py', 'read_validation_v2.py',
    'prepare-resume-after-base-01.log', 'inspect-base-01.log',
    'validation-readiness-01.json', 'validation-progress-02-capture.log',
    'validation-progress-02.json', 'validation-progress-02-ended.json',
    'validation-progress-03-capture.log', 'validation-progress-03.json',
]:
    files[name] = (ROOT / name).read_bytes()
for folder in ['validation-progress-02-snapshot', 'validation-progress-03-snapshot']:
    for path in sorted((ROOT / folder).rglob('*')):
        if path.is_file():
            files[str(path.relative_to(ROOT))] = path.read_bytes()
for folder in ['base-01', 'resume-after-base-01']:
    for path in sorted((ROOT / folder).iterdir()):
        if path.is_file():
            files[str(path.relative_to(ROOT))] = path.read_bytes()
for name in ['data.pt', 'dapo_progress.json']:
    path = ROOT / 'resume-after-base-01/preserved/global_step_25' / name
    files[str(path.relative_to(ROOT))] = path.read_bytes()
for name in ['research/dapo_progress_20260908/resume_progress.py',
             'research/training_submission_20260907/capture_progress.py',
             'research/base_signal_diagnostic_20260907/analyze_events.py']:
    files['source/' + name] = (PROJECT / name).read_bytes()
files['archive_preparation.py'] = Path(__file__).read_bytes()
plan = json.loads(files['resume-after-base-01/prepared.json'])
assert plan['matched_evaluation_controller_sha256'] == sha(files['control_matched_evaluation.py'])
assert plan['controller_sha256'] == sha(files['source/research/dapo_progress_20260908/resume_progress.py'])
assert plan['resolved_sha256'] == sha(files['resume-after-base-01/resolved.yaml'])
assert plan['step'] == 25
assert not any(name.endswith('paused-source.json') or name == 'base-01/launch.json' for name in files)
for name in ['validation-progress-02-ended.json', 'validation-progress-03.json']:
    report = json.loads(files[name])
    assert not report['complete_official_pass']
    assert report['reader_sha256'] == sha(files['read_validation_v2.py'])
archive = ROOT / 'matched-evaluation-preparation-evidence.tar.gz'
manifest = archive.with_name('matched-evaluation-preparation-evidence.sha256.json')
assert not archive.exists() and not manifest.exists()
with archive.open('xb') as stream, tarfile.open(fileobj=stream, mode='w:gz') as target:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        target.addfile(info, io.BytesIO(data))
metadata = {
    'archive_sha256': sha(archive.read_bytes()),
    'archive_bytes': archive.stat().st_size,
    'members': {name: sha(data) for name, data in sorted(files.items())},
    'scope': 'Actual native CPU recovery/configuration preparation and partial validation snapshots. No base GPU pass, training pause, or GPU restoration has been executed by this controller.',
}
with manifest.open('x') as stream:
    json.dump(metadata, stream, indent=2)
    stream.write('\n')
print(json.dumps({k: v for k, v in metadata.items() if k != 'members'} | {'member_count': len(files)}))
