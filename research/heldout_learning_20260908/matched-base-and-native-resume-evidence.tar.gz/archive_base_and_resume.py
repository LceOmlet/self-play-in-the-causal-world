"""Freeze completed matched validation and actual native training resumption."""

import hashlib
import io
import json
import os
import subprocess
import tarfile
import time
from pathlib import Path

import psutil

ROOT = Path('/home/chen/runs/heldout-learning-20260908')
PROJECT = Path('/home/chen/projects/self-play-in-the-causal-world-rewardv10-a92ab8e-20260831')
DATA = Path('/home/chen/runs/training-submission-20260907/data')
RUN = ROOT / 'resume-after-base-01'
members = {}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def add(path, name):
    assert path.is_file() and not path.is_symlink() and name not in members
    content = path.read_bytes()
    assert len(content) < 25_000_000, path
    members[name] = content


def add_json(name, data):
    assert name not in members
    members[name] = (json.dumps(data, indent=2, allow_nan=False) + '\n').encode()


for name in [
    'read_validation_v2.py', 'inspect_validation_stops_v2.py',
    'control_matched_evaluation.py', 'prepare_base_validation.py',
    'analyze_completed_decisions.py', 'analyze_completed_decisions_v2.py',
    'analyze_completed_decisions_v3.py', 'compare_matched_validation.py',
    'base-complete-capture.log', 'base-validation.json', 'base-validation-reader.log',
    'base-stops.json', 'base-stops.log', 'base-vs-update25.json', 'base-vs-update25.log',
    'completed-decision-diagnosis.json', 'completed-decision-diagnosis.log',
    'completed-decision-diagnosis-v2.log', 'completed-decision-diagnosis-v3.json',
    'completed-decision-diagnosis-v3.log', 'resume-after-base-01-launch.log',
    'resume-started-capture.log', 'preserved-update26-acceptance.json',
    'audit_native26.py', 'audit-native26.log', 'update25-validation.json',
    'update25-stops.json', 'preserved-update25-acceptance.json',
    'evidence.sha256.json', 'update25-validation-and-base-launch-evidence.sha256.json',
]:
    add(ROOT / name, name)
for folder in ['base-complete-snapshot', 'resume-started-snapshot', 'update25-complete-snapshot']:
    for path in sorted((ROOT / folder).rglob('*')):
        if path.is_file():
            add(path, path.relative_to(ROOT).as_posix())
for folder in ['base-01', 'resume-after-base-01']:
    for path in sorted((ROOT / folder).iterdir()):
        if path.is_file():
            add(path, path.relative_to(ROOT).as_posix())
for step in [25, 26]:
    for name in ['data.pt', 'dapo_progress.json']:
        path = ROOT / f'preserved/global_step_{step}' / name
        add(path, path.relative_to(ROOT).as_posix())
for name in ['validation.parquet', 'acceptance.json', 'accepted.jsonl']:
    add(DATA / name, 'data/' + name)
for index in [8, 13, 18, 23]:
    add(DATA / f'truth/validation-{index:04d}.pkl', f'data/truth/validation-{index:04d}.pkl')
for name in ['src/cpt_world/query_truth.py', 'src/cpt_world/verl_environment.py',
             'research/dapo_progress_20260908/resume_progress.py',
             'research/training_submission_20260907/capture_progress.py',
             'research/base_signal_diagnostic_20260907/analyze_events.py']:
    add(PROJECT / name, 'source/' + name)
add(Path(__file__), 'archive_base_and_resume.py')

exit_state = json.loads(members['base-01/exit.json'])
assert exit_state['exit_code'] == 0 and exit_state['complete_validation_only']
assert not exit_state['wall_limit_reached'] and exit_state['acceptance_error'] is None
before = json.loads(members['base-validation.json'])
after = json.loads(members['update25-validation.json'])
assert before['complete_official_pass'] and after['complete_official_pass']
assert len(before['records']) == len(after['records']) == 25
assert before['outputs_sha256'] == sha(members['base-complete-snapshot/validation/0.jsonl'])
assert after['outputs_sha256'] == sha(members['update25-complete-snapshot/validation/25.jsonl'])
comparison = json.loads(members['base-vs-update25.json'])
assert comparison['before_report_sha256'] == sha(members['base-validation.json'])
assert comparison['after_report_sha256'] == sha(members['update25-validation.json'])
assert comparison['script_sha256'] == sha(members['compare_matched_validation.py'])
diagnosis = json.loads(members['completed-decision-diagnosis-v3.json'])
assert diagnosis['script_sha256'] == sha(members['analyze_completed_decisions_v3.py'])
assert [r['index'] for r in diagnosis['records']] == [8, 13, 18, 23]
for row in diagnosis['records']:
    assert row['truth_file_sha256'] == sha(members[f"data/truth/validation-{row['index']:04d}.pkl"])
native = json.loads(members['preserved-update26-acceptance.json'])
assert native['auditor_sha256'] == sha(members['audit_native26.py'])
for name in ['data.pt', 'dapo_progress.json']:
    assert native['files'][name] == sha(members['preserved/global_step_26/' + name])

# Retain the dead base worker log using its recorded live identity and prefix.
# The completed snapshot's failed live lookup is preserved unchanged.
source = ROOT / 'base-started-snapshot/task-runner-source.json'
prefix = ROOT / 'base-started-snapshot/task-runner-stdout.log'
add(source, 'base-historical-task-runner/recorded-live-source.json')
add(prefix, 'base-historical-task-runner/startup-prefix.log')
identity = json.loads(source.read_text())
complete = Path(identity['source']).read_bytes()
assert sha(prefix.read_bytes()) == identity['sha256'] and complete.startswith(prefix.read_bytes())
members['base-historical-task-runner/complete.log'] = complete
add_json('base-historical-task-runner/proof.json', dict(recorded_pid=identity['pid'],
    recorded_create_time=identity['create_time'], prefix_bytes=identity['bytes'],
    full_bytes=len(complete), full_sha256=sha(complete), prefix_match=True,
    scope='Post-exit read at the path recorded while owned worker was alive; no current live PID claim.'))

identity = json.loads(members['resume-after-base-01/process.json'])
process = psutil.Process(identity['pid'])
assert abs(process.create_time() - identity['create_time']) < 0.01
assert process.is_running() and process.status() != psutil.STATUS_ZOMBIE
assert not (RUN / 'exit.json').exists()
source = json.loads(members['resume-started-snapshot/task-runner-source.json'])
worker = psutil.Process(source['pid'])
assert abs(worker.create_time() - source['create_time']) < 0.01
assert worker.pid in {child.pid for child in process.children(recursive=True)}
assert os.readlink(f'/proc/{worker.pid}/fd/1') == source['source']
content = Path(source['source']).read_bytes()
assert content.startswith(members['resume-started-snapshot/task-runner-stdout.log'])
members['resume-latest-owned-task-runner.log'] = content
add_json('live-status-at-archive.json', dict(time=time.time(), process=identity,
    same_process_live=True, latest_checkpoint_tracker=(RUN / 'checkpoints/latest_checkpointed_iteration.txt').read_text().strip(),
    project_head=subprocess.check_output(['git', '-C', str(PROJECT), 'rev-parse', 'HEAD'], text=True).strip(),
    scope='Training continues. Tensor and complete rollout acceptance is update26; later tracker is a read-only status.'))

archive = ROOT / 'matched-base-and-native-resume-evidence.tar.gz'
manifest = ROOT / 'matched-base-and-native-resume-evidence.sha256.json'
assert not archive.exists() and not manifest.exists()
with archive.open('xb') as handle, tarfile.open(fileobj=handle, mode='w:gz') as tar:
    for name, data in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode = len(data), 0o644
        tar.addfile(info, io.BytesIO(data))
metadata = dict(archive_sha256=sha(archive.read_bytes()), archive_bytes=archive.stat().st_size,
    members={name: sha(data) for name, data in sorted(members.items())},
    scope='Complete matched base/update25 validation; four actual causal-decision audits; actual native update26 and continuing training. No aggregate learning gain established.')
with manifest.open('x') as handle:
    json.dump(metadata, handle, indent=2)
    handle.write('\n')
print(json.dumps({k: v for k, v in metadata.items() if k != 'members'} | {'member_count': len(members)}))
