"""Read-only CPU acceptance of the already preserved actual update 26."""

import hashlib
import json
import os
import sys
from pathlib import Path
from unittest.mock import Mock

os.environ.update(CUDA_VISIBLE_DEVICES="", OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1")
ROOT = Path('/home/chen/runs/heldout-learning-20260908')
PROJECT = Path('/home/chen/projects/self-play-in-the-causal-world-rewardv10-a92ab8e-20260831')
VERL = Path('/home/chen/vendor/dapo-official-20260906/verl-progress-candidate-v2')
RECIPE = Path('/home/chen/vendor/dapo-official-20260906/verl-recipe-progress-candidate-v2')
sys.path[:0] = [str(PROJECT / 'src'), str(PROJECT), str(RECIPE), str(VERL)]

import torch
from dapo.dapo_ray_trainer import RayDAPOTrainer
from omegaconf import OmegaConf
from torch.distributed.tensor import DTensor
from torchdata.stateful_dataloader import StatefulDataLoader
from verl.trainer.ppo.utils import create_rl_sampler


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def local(tensor):
    return tensor.to_local() if isinstance(tensor, DTensor) else tensor


checkpoint = ROOT / 'preserved/global_step_26'
previous = ROOT / 'preserved/global_step_25'
run = ROOT / 'resume-after-base-01'
assert sha(RECIPE / 'dapo/dapo_ray_trainer.py') == 'b8e66a6037e3b2922f560c24eb10a94dc28a916579d2f163b506adb82559f491'
assert sha(VERL / 'verl/trainer/ppo/ray_trainer.py') == '4ade49b9c8e80d51a21240e3f07df1fb1215afac365e9424af076b84e88f8e7b'
files = {str(p.relative_to(checkpoint)): sha(p) for p in checkpoint.rglob('*') if p.is_file()}
live_source = run / 'checkpoints/global_step_26'
assert live_source.exists(), 'Published source was retained at comparison time'
assert all(sha(live_source / name) == digest for name, digest in files.items())


def load(folder, name):
    return torch.load(folder / name, map_location='cpu', weights_only=False)


model = load(checkpoint, 'actor/model_world_size_1_rank_0.pt')
old_model = load(previous, 'actor/model_world_size_1_rank_0.pt')
assert len(model) == 496 and set(model) == set(old_model)
assert all('lora_' in name and torch.isfinite(local(tensor)).all() for name, tensor in model.items())
changed = sum(not torch.equal(local(tensor), local(old_model[name])) for name, tensor in model.items())
assert changed == 496
states = [s for s in load(checkpoint, 'actor/optim_world_size_1_rank_0.pt')['state'].values() if s]
assert len(states) == 496 and all(float(local(s['step'])) == 26 for s in states)
assert all(torch.isfinite(local(s[key])).all() for s in states for key in ['exp_avg', 'exp_avg_sq'])
assert load(checkpoint, 'actor/extra_state_world_size_1_rank_0.pt')['lr_scheduler']['last_epoch'] == 26
data = load(checkpoint, 'data.pt')
assert data['_num_yielded'] == 30 and not data['_iterator_finished']
assert load(previous, 'data.pt')['_num_yielded'] == 29
progress = json.loads((checkpoint / 'dapo_progress.json').read_text())
assert progress == dict(version=1, completed_updates=26, generated_batches=30, data_epoch=0, batches_per_epoch=500)
config = OmegaConf.load(run / 'resolved.yaml')
assert config.trainer.resume_mode == 'resume_path'
config.trainer.resume_from_path = str(checkpoint)


def loader():
    rows = list(range(500))
    return StatefulDataLoader(rows, batch_size=1, num_workers=0, drop_last=True,
                              sampler=create_rl_sampler(config.data, rows))


trainer = object.__new__(RayDAPOTrainer)
trainer.config, trainer.global_steps, trainer.use_critic = config, 0, False
trainer.actor_rollout_wg = Mock()
trainer.train_dataloader = loader()
trainer._load_checkpoint()
assert trainer.global_steps == 26 and trainer.gen_steps == 30 and trainer.data_epoch == 0
iterator = iter(trainer.train_dataloader)
actual = [int(next(iterator).item()) for _ in range(8)]
iterator = iter(loader())
consumed = [int(next(iterator).item()) for _ in range(30)]
expected = [int(next(iterator).item()) for _ in range(8)]
assert consumed[-1] == 93 and actual == expected and not torch.cuda.is_initialized()
snapshot = json.loads((ROOT / 'resume-started-snapshot/progress.json').read_text())
metrics = [m for m in snapshot['official_metrics'] if m.get('step') == 26 and 'actor/grad_norm' in m]
assert len(metrics) == 1 and metrics[0]['actor/grad_norm'] > 0 and not snapshot['nonfinite_metrics']
assert len(snapshot['retained_rollouts']) == 4
report = dict(checkpoint=str(checkpoint), files=files, source_copy_hashes_match=True,
              step=26, finite_lora_tensors=496, changed_lora_tensors=changed,
              finite_optimizer_states=496, finite_optimizer_moments=992,
              scheduler_step=26, generated_batches=30, previous_generated_batches=29,
              data_epoch=0, next_rows=actual, continuous_next_rows=expected,
              expected_consumed_training_row=consumed[-1], official_metrics=metrics[0],
              auditor_sha256=sha(__file__), configuration_sha256=sha(run / 'resolved.yaml'),
              snapshot_sha256=sha(ROOT / 'resume-started-snapshot/progress.json'),
              scope='Actual published update26 tensors/counters and CPU official data restoration. '
                    'GPU RPC is mocked only in this independent CPU load check; this does not replay GPU training.')
with (ROOT / 'preserved-update26-acceptance.json').open('x') as handle:
    json.dump(report, handle, indent=2, allow_nan=False)
    handle.write('\n')
print(json.dumps({k: v for k, v in report.items() if k not in ['files', 'official_metrics']}))
