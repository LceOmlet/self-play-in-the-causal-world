"""Inspect complete official outputs against their uniquely joined owner events.

No generation or reward code is replaced. Visible decoded text is not claimed
to preserve the original token IDs or exact response-mask length.
"""

import argparse
import hashlib
import importlib.util
import json
import re
from collections import Counter, defaultdict
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    loaded = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = json.loads(args.report.read_text())
    assert report["complete_official_pass"] and len(report["records"]) == 25
    dump = args.snapshot / "validation" / f"{report['step']}.jsonl"
    assert sha(dump.read_bytes()) == report["outputs_sha256"]
    outputs = {
        sha(row["input"].encode()): row
        for row in [json.loads(line) for line in dump.read_bytes().splitlines()]
    }
    assert len(outputs) == 25
    owner = module(
        args.project / "research/base_signal_diagnostic_20260907/analyze_events.py", "owner"
    )
    events, fingerprints = owner.read_events(args.snapshot)
    assert fingerprints == report["event_prefixes"]
    traces = defaultdict(list)
    for event in events:
        if event["event"] == "act":
            traces[event["trajectory_id"]].append(event)
    call = re.compile(
        r"<tool_call>\s*<function=act>\s*<parameter=command>\s*"
        r"(.*?)\s*</parameter>\s*</function>\s*</tool_call>",
        re.DOTALL,
    )
    records = []
    for record in report["records"]:
        output = outputs[record["input_sha256"]]["output"]
        assert sha(output.encode()) == record["output_sha256"]
        trace = traces.get(record["request_id"], [])
        calls = list(call.finditer(output))
        assert len(calls) == len(trace)
        matches = []
        for i, (match, event) in enumerate(zip(calls, trace, strict=True)):
            segment = output[match.end() : calls[i + 1].start() if i + 1 < len(calls) else None]
            matches.append(event["feedback"] in segment)
        last = trace[-1] if trace else None
        suffix = output[calls[-1].end() :] if calls else output
        observation = (
            "terminal_answer_executed"
            if record["completed"]
            else "ends_at_executed_nonterminal_call_without_feedback"
            if calls and not suffix.strip() and not matches[-1]
            else "other_unfinished_output"
        )
        counts = Counter(json.dumps(event["command"], sort_keys=True) for event in trace)
        records.append(
            {
                "index": record["index"],
                "tape_key": record["tape_key"],
                "query_type": record["query_type"],
                "request_id": record["request_id"],
                "completed": record["completed"],
                "observation": observation,
                "output_sha256": record["output_sha256"],
                "output_characters": len(output),
                "executed_calls": len(trace),
                "feedback_exactly_present_after_each_call": matches,
                "observations_used": last["observations_used"] if last else 0,
                "last_command": last["command"] if last else None,
                "last_feedback_characters": len(last["feedback"]) if last else 0,
                "last_feedback_sha256": sha(last["feedback"].encode()) if last else None,
                "most_repeated_command": json.loads(counts.most_common(1)[0][0])
                if counts
                else None,
                "most_repeated_command_count": counts.most_common(1)[0][1] if counts else 0,
                "output_tail": output[-1800:],
            }
        )
    result = {
        "reader_sha256": sha(Path(__file__).read_bytes()),
        "validation_report_sha256": sha(args.report.read_bytes()),
        "observations": dict(Counter(record["observation"] for record in records)),
        "scope": "Observations from full decoded official output and matched owner events. "
        "Exact token IDs and response-mask lengths were not preserved by the official text dump. "
        "Stop-path attribution additionally requires inspection of the actual official source.",
        "records": records,
    }
    with args.output.open("x") as handle:
        json.dump(result, handle, indent=2)
        handle.write("\n")
    print(json.dumps(result["observations"]))


if __name__ == "__main__":
    main()
