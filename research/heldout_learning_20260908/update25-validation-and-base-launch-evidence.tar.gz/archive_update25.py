"""Freeze completed update25 validation and the owned base launch evidence."""

import hashlib
import io
import json
import os
import tarfile
import time
from pathlib import Path

import psutil

ROOT = Path('/home/chen/runs/heldout-learning-20260908')
TRAIN = Path('/home/chen/runs/dapo-progress-20260908/resume-progress-01')
PROJECT = Path('/home/chen/projects/self-play-in-the-causal-world-rewardv10-a92ab8e-20260831')
VERL = Path('/home/chen/vendor/dapo-official-20260906/verl-progress-candidate-v2')


def sha(data):
    return hashlib.sha256(data).hexdigest()


files = {}
for name in [
    'control_matched_evaluation.py', 'read_validation_v2.py',
    'inspect_validation_stops.py', 'inspect_validation_stops_v2.py',
    'update25-complete-capture.log', 'update25-validation.json',
    'update25-validation-reader.log', 'update25-stop-observations.json',
    'update25-stop-observations.log', 'update25-stops.json', 'update25-stops.log',
    'pause-for-base-01.log', 'launch-base-01.log', 'base-started-capture.log',
]:
    files[name] = (ROOT / name).read_bytes()
for folder in ['update25-complete-snapshot', 'base-started-snapshot']:
    for path in sorted((ROOT / folder).rglob('*')):
        if path.is_file():
            files[str(path.relative_to(ROOT))] = path.read_bytes()
for folder in ['base-01', 'resume-after-base-01']:
    for path in sorted((ROOT / folder).iterdir()):
        if path.is_file() and path.name != 'train.log':
            files[str(path.relative_to(ROOT))] = path.read_bytes()
for name in ['resolved.yaml', 'process.json', 'exit.json']:
    files['training-after-pause/' + name] = (TRAIN / name).read_bytes()
for name in ['data.pt', 'dapo_progress.json']:
    path = ROOT / 'resume-after-base-01/preserved/global_step_25' / name
    files[str(path.relative_to(ROOT))] = path.read_bytes()
for path, archive_name in [
    (PROJECT/'src/cpt_world/verl_environment.py', 'source/verl_environment.py'),
    (PROJECT/'research/training_submission_20260907/capture_progress.py', 'source/capture_progress.py'),
    (PROJECT/'research/base_signal_diagnostic_20260907/analyze_events.py', 'source/analyze_events.py'),
    (VERL/'verl/workers/reward_manager/dapo.py', 'source/dapo_reward_manager.py'),
    (VERL/'verl/experimental/agent_loop/tool_agent_loop.py', 'source/tool_agent_loop.py'),
    (VERL/'verl/experimental/agent_loop/agent_loop.py', 'source/agent_loop.py'),
    (VERL/'verl/trainer/ppo/ray_trainer.py', 'source/ray_trainer.py'),
]:
    files[archive_name] = path.read_bytes()
files['archive_update25.py'] = Path(__file__).read_bytes()
identity=json.loads(files['base-01/process.json'])
process=psutil.Process(identity['pid'])
assert abs(process.create_time()-identity['create_time'])<0.01 and process.is_running()
assert not (ROOT/'base-01/exit.json').exists()
assert not (ROOT/'resume-after-base-01/supervisor.json').exists()
owned=[]
for child in [process, *process.children(recursive=True)]:
    try:
        stdout=Path(os.readlink(f'/proc/{child.pid}/fd/1'))
        if stdout.is_file() and stdout.suffix in ['.out', '.err']:
            files['base-owned-logs/' + stdout.name] = stdout.read_bytes()
            stderr=stdout.with_suffix('.err')
            if stderr.exists():
                files['base-owned-logs/' + stderr.name] = stderr.read_bytes()
        owned.append({'pid':child.pid,'create_time':child.create_time(),'name':child.name(),'stdout':str(stdout)})
    except (OSError, psutil.Error):
        continue
files['base-owned-processes.json'] = (json.dumps({'time':time.time(),'process':identity,'owned':owned},indent=2)+'\n').encode()
report=json.loads(files['update25-validation.json'])
stops=json.loads(files['update25-stops.json'])
assert report['complete_official_pass'] and len(report['records'])==25
assert report['outputs_sha256']==sha(files['update25-complete-snapshot/validation/25.jsonl'])
assert stops['reader_sha256']==sha(files['inspect_validation_stops_v2.py'])
assert stops['validation_report_sha256']==sha(files['update25-validation.json'])
assert stops['configuration_sha256']==sha(files['training-after-pause/resolved.yaml'])
assert stops['stop_paths']=={'terminal_answer':11,'generation_response_limit':11,'tool_feedback_response_limit':3}
proof=json.loads(files['resume-after-base-01/completed-validation-before-pause.json'])
assert proof['dump_sha256']==report['outputs_sha256'] and proof['records']==25
assert all(report['official_metrics'][k]==v for k,v in proof['metrics'].items())
archive=ROOT/'update25-validation-and-base-launch-evidence.tar.gz'
manifest=archive.with_name('update25-validation-and-base-launch-evidence.sha256.json')
assert not archive.exists() and not manifest.exists()
with archive.open('xb') as stream, tarfile.open(fileobj=stream, mode='w:gz') as target:
    for name,data in sorted(files.items()):
        info=tarfile.TarInfo(name); info.size=len(data); info.mode=0o644
        target.addfile(info,io.BytesIO(data))
metadata={'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,
          'members':{name:sha(data) for name,data in sorted(files.items())},
          'scope':'Full official update25 validation, exact event/source analysis, preserved native pause, and actual original-base val_only launch. Base run is live, its full result and native GPU training resumption remain pending.'}
with manifest.open('x') as stream:
    json.dump(metadata,stream,indent=2); stream.write('\n')
print(json.dumps({k:v for k,v in metadata.items() if k!='members'}|{'member_count':len(files)}))
