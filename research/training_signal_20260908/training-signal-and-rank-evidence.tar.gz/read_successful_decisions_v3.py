"""Extract all four successful strong-reversal training trajectories through29."""

import hashlib
import json
import pickle
import sys
from pathlib import Path

PROJECT = Path('/home/chen/projects/self-play-in-the-causal-world-rewardv10-a92ab8e-20260831')
ROOT = Path('/home/chen/runs/heldout-learning-20260908')
sys.path[:0] = [str(PROJECT/'src'), str(PROJECT)]
from research.training_submission_20260907.capture_progress import commands_from_output

records = []
for snapshot, step, index in [
    (ROOT/'update25-complete-snapshot',16,433),
    (ROOT/'update25-complete-snapshot',19,33),
    (ROOT/'training-signal-01-snapshot',26,93),
]:
    progress=json.loads((snapshot/'progress.json').read_text())
    retained=[r for r in progress['retained_rollouts'] if r['step']==step and r['task_metrics']['optimal_action']]
    events=[json.loads(line) for path in (snapshot/'environment').glob('*.jsonl') for line in path.read_bytes().splitlines()]
    outputs=[json.loads(line) for line in (snapshot/f'rollouts/{step}.jsonl').read_bytes().splitlines()]
    path=ROOT.parent/'training-submission-20260907/data/truth'/f'train-{index:04d}.pkl'
    row,world,seed,truth=pickle.loads(path.read_bytes())
    labels=seed['visible_schema']['variable_labels']
    for r in retained:
        trace=[e for e in events if e['event']=='act' and e['trajectory_id']==r['request_id']]
        matches=[o for o in outputs if commands_from_output(o['output'])==[e['command'] for e in trace]]
        assert len(matches)==1 and r['tape_key']==row['tape_key']
        output=matches[0]['output']
        query=seed['query']
        x,y=query['decision_target'],query['outcome']
        k=next(world.domains[i] for i,v in enumerate(world.variables) if labels[v]==x)
        state=int(query['outcome_state'].removeprefix('state_'))
        batches=[]
        for event in trace:
            if event['completed']:
                continue
            feedback=json.loads(event['feedback'].splitlines()[0])
            if feedback['type']!='batch_result' or event['command']['type']!='observe':
                continue
            histogram=feedback['batch']['joint_histogram']
            columns=histogram['columns']
            if not {x,y}<=set(columns):
                continue
            xi,yi=columns.index(x),columns.index(y)
            totals,successes=[0]*k,[0]*k
            for values,count in histogram['rows']:
                totals[values[xi]]+=count
                successes[values[xi]]+=count*(values[yi]==state)
            batches.append(dict(n=feedback['batch']['n'],columns=columns,totals=totals,successes=successes))
        aggregate={}
        for name,subset in [('all',batches),('last',batches[-1:]),('last_three',batches[-3:])]:
            totals=[sum(b['totals'][i] for b in subset) for i in range(k)]
            successes=[sum(b['successes'][i] for b in subset) for i in range(k)]
            aggregate[name]=dict(totals=totals,successes=successes,probabilities=[s/n if n else None for s,n in zip(successes,totals)])
        text=output
        for event in trace:
            if event['completed']:
                continue
            feedback=event['feedback']
            assert feedback in text
            text=text.replace(feedback, '[recorded tool feedback removed]', 1)
        records.append(dict(step=step,index=index,request_id=r['request_id'],
            query=seed['query'],parents={labels[v]:[labels[world.variables[p]] for p in world.parents[i]] for i,v in enumerate(world.variables)},
            truth=truth,output_sha256=hashlib.sha256(output.encode()).hexdigest(),
            observational_shortcut=trace[-1]['terminal_score']['observational_shortcut'],
            observational_choice=trace[-1]['terminal_score']['observational_choice'],
            natural_joint_batches=batches,empirical_aggregate=aggregate,
            output=output,without_recorded_feedback=text,
            commands=[e['command'] for e in trace]))
assert len(records)==4
with (ROOT/'successful-strong-decisions-through29-v3.json').open('x') as handle:
    json.dump(records,handle,indent=2);handle.write('\n')
for record in records:
    print(json.dumps({k:v for k,v in record.items() if k not in ['output','without_recorded_feedback','commands','natural_joint_batches','parents','truth']}))
