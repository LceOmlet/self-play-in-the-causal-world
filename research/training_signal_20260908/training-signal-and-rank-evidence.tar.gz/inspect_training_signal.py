"""Inspect completed trusted trajectory groups without invoking a trainer."""

import json
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path('/home/chen/runs')
paths = [ROOT/'inference-efficiency-20260908/post-pause-snapshot',
         ROOT/'dapo-progress-20260908/compiled-through15-snapshot',
         ROOT/'heldout-learning-20260908/update25-complete-snapshot',
         ROOT/'heldout-learning-20260908/training-signal-01-snapshot']
accepted = [json.loads(x) for x in (ROOT/'training-submission-20260907/data/accepted.jsonl').read_bytes().splitlines()]
tasks = {r['tape_key']: r for r in accepted if r['split'] == 'train'}
groups, metrics, by_request = defaultdict(list), {}, {}
for path in paths:
    data = json.loads((path/'progress.json').read_text())
    assert not data['nonfinite_metrics']
    for m in data['official_metrics']:
        if 'actor/grad_norm' in m:
            assert m['step'] not in metrics
            metrics[m['step']] = m
    for row in data['retained_rollouts']:
        assert row['event_join_method'] != 'unresolved' and row['tape_key'] in tasks
        groups[row['step']].append(row)
    for row in data['trajectories']:
        assert row['trajectory_id'] not in by_request
        by_request[row['trajectory_id']] = row
assert sorted(groups) == sorted(metrics) == list(range(1,30))
family = defaultdict(list)
for step, rows in sorted(groups.items()):
    assert len(rows)==4 and len({r['tape_key'] for r in rows}) == 1
    mean = sum(r['shaped_reward_from_components'] for r in rows)/4
    assert abs(mean-metrics[step]['critic/score/mean']) < 1e-6
    key = rows[0]['query_type']; task=tasks[rows[0]['tape_key']]
    answer_rows=[]
    for r in rows:
        trace = by_request[r['request_id']]
        strict = None
        keys = {'backadj_minimal_sets':['valid_adjustment_set'], 'best_intervention':['optimal_action'],
                'mediator_set':['mediators_exact_match','order_exact_match']}.get(key)
        if keys:
            strict=bool(r['completed'] and all(r['task_metrics'][k] for k in keys))
        answer_rows.append(dict(request_id=r['request_id'], answer=trace['answer'],
            quality=r['raw_quality'], penalty=r['official_overlong_reward'],
            above_mean=r['shaped_reward_from_components']>mean, strict=strict,
            interventions=trace['valid_experiments'].get('intervene',0)))
    item=dict(step=step, family=key, task_index=task['index'],
              discordant=task.get('discordant'), rows=answer_rows)
    family[key].append(item)
    print(json.dumps(item))
print('SUMMARY')
for key,items in family.items():
    rows=[r for item in items for r in item['rows']]
    print(key, json.dumps(dict(groups=len(items), completed=sum(r['answer'] is not None for r in rows),
        strict_correct=sum(r['strict'] is True for r in rows),
        positive=sum(r['above_mean'] for r in rows),
        strict_positive=sum(r['above_mean'] and r['strict'] is True for r in rows),
        quality_positive_wrong=sum(r['above_mean'] and r['strict'] is False for r in rows),
        penalized=sum(r['penalty']<0 for r in rows))))
print('generated',sum(int(m['train/num_gen_batches']) for m in metrics.values()))
